#############################################################################
# Name       : percent_offline.sh                          		    #
# Description: To find PIAM offline controller by percentage status report  #
# Auto Mail  : Yes                                                          #
# Author     : Deepak Patel                                                 #
#############################################################################

#!/bin/bash

NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
MailToList="Jio.TopsSLPAppSupport@ril.com"
#MailToList="deepak10.patel@ril.com" 
MAILX='mailx'

#sed -i 1d /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql.csv

sed -i -e 's/[a-zA-Z].*//' /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql.csv

sed -i '/^$/d' /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql.csv

awk -F "," '{divide = ($3/$2*100);print $1,$2,$3,divide "%"}' /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql.csv > /home/jioapp/mailoutput/generic/percent_offline.csv

sed -i 's/ /,/g' /home/jioapp/mailoutput/generic/percent_offline.csv

sort -t, -nk4 -r -o /home/jioapp/mailoutput/generic/percent_offline.csv /home/jioapp/mailoutput/generic/percent_offline.csv

sed -i -e '1i hostid,total,offline,offline_percent' /home/jioapp/mailoutput/generic/percent_offline.csv

offline_file='/home/jioapp/mailoutput/generic/percent_offline.csv'

cat > $Mailbody << EOF
Dear All,

Please find the percentage of offline controller by hostid for $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Percentage offline controllers by hostid $NOW" -r "jionoc.it@ril.com" -a $offline_file $MailToList < $Mailbody
