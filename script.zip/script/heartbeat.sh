#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"Output_CoreCount.$NOW.csv"
MailToList="Jio.TopsSLPAppSupport@ril.com,JioNOC.ITDRSupport@ril.com" 
MAILX='mailx'

var=`/usr/local/pgsql/bin/psql $dbname $username << EOF
select id_host, count (*) from piamapp."controllerMaster" where id_host not in (select id_host from piamapp."controllerMaster" where lastheartbeat >=now()-interval '60 mins') group by id_host order by id_host;
EOF`

echo $var > $HOME/sql/OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find ID Hosts where Heartbeat not received for last 1 hour with Total Controller counts on the host.

$var


Regards,
JIONOC IT
EOF

$MAILX -s "No Heartbeat Data in last one hour – ID_Host  $NOW" -r "jionoc.it@ril.com" $MailToList < $Mailbody


