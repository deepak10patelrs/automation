###############################################################################################
# Name       : ageing_report.sh				       		      		      #
# Description: It contains ageing report for controllers not working in PIAM for last 20 days #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/Ageing_Controller_Status/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/Ageing_Controller_Status/"Output_CoreCount.$NOW.csv"
MailToList="deepak10.patel@ril.com,Sankara.Suravaram@ril.com,Haroon.Ahmed@ril.com,Rahul1.dalvi@ril.com,Jaideep.mokha@ril.com,rashmi1.rai@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"

MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (SELECT controllerip, macid,lastheartbeat,createdon FROM piamapp."controllerMaster" where lastheartbeat < now() - interval '20 Day' and isonline='f' order by lastheartbeat) TO '/home/jioapp/mailoutput/Ageing_Controller_Status/Output_CoreCount.csv' With CSV HEADER
EOF`

cat /home/jioapp/mailoutput/Ageing_Controller_Status/Output_CoreCount.csv > $OUPUTFILECSV


cat > $Mailbody << EOF
Dear All,

Please find the Ageing Controllers Report  $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Ageing report for controllers not working in PIAM for last 20 days $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody


