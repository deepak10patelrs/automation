#!/bin/bash

dbname="PIAM_TRANS_DB"
username="postgres"
val=`date +%d%m%Y`
Mailbody=/home/jioapp/mailoutput/generic/MAILBODYRARS
MailToList="deepak10.patel@ril.com"

MAILX='mailx'

COUNT1=`/usr/local/pgsql/bin/psql $dbname $username << EOF
select count(*) from public.view_card_swipe_in_out where occurrencedate='$val' and eventdate>=NOW()- Interval '60 mins' 
EOF`

COUNT2=`/usr/local/pgsql/bin/psql $dbname $username << EOF
select count(*) FROM public.view_card_swipe_in_out_shift where occurrencedate='$val' and eventdate>=NOW()- Interval '30 mins'
EOF`

output=`echo $COUNT1|awk '{print $3}'`

cat > $Mailbody << EOF
Dear All,

PIAM To RARS Attendance Flow Count For Last 60 minutes. PLEASE CHECK ATTENDANCE SCHEDULER AND LOGS.

$output


Regards,
JIONOC IT
EOF


if [ $output -le 0 ]
then
`$MAILX -s "PIAM To RARS Attendance Flow Count For Last 60 minutes on $NOW" -r "jionoc.it@ril.com" $MailToList < $Mailbody`
fi

