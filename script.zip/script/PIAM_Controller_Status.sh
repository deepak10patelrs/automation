###########################################################
# Name       : PIAM_Controller_Status.sh		  #
# Description: To find PIAM all controller status report  #
# Auto Mail  : Yes					  #
# Author     : Deepak Patel				  #
###########################################################


#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
day=`date|awk '{print $3}'`
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV1=/home/jioapp/mailoutput/generic/"Output_CoreCount_all1.$NOW.csv"
MailToList="Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Rahul1.Dalvi@ril.com,Ritesh.Parekh@ril.com,Sanket.Kulkarni@ril.com,Jaideep.Mokha@ril.com,Govind.M.Mishra@ril.com,thisore.raghu@zmail.ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
#MailToList="deepak10.patel@ril.com"
date_var=`date +%d/%m/%Y`
MAILX='mailx'

cat > $Mailbody << EOF
Dear All,

Please find PIAM All Controllers Status trend report for $NOW


Regards,
JIONOC IT
EOF


temp_var1=`head -1 /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv|cut -d"," -f2-`
temp_var2=`head -2 /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv|tail -1|cut -d"," -f2-`
total_final=`tail /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv|grep "^Total"|cut -d"," -f2-`


`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (select id_host as host, count(*) as Total, sum(case when isonline='f' then 1 else 0 end) as offline from piamapp."controllerMaster" group by id_host order by id_host) TO '/home/jioapp/mailoutput/generic/Output_CoreCount_all_sql.csv' WITH CSV 
EOF`

cat /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql.csv|awk -F "," '{sum1 +=$(NF-1)} {sum2 +=$NF} END {print "Total",",",sum1,",",sum2} {print $0}' > /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv

total=`grep Total /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv|sed 's/ //g'`

sed -i '$d' /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv

sed -i -e '1,2d' /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv

sed -i '$d' /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv

sort -t, -k1,1 -o /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv

sort -t, -k1,1 -o /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv

#join -t, -1 1 -2 1 /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv > /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv

join -t, -a 1 -1 1 -2 1 /home/jioapp/mailoutput/generic/Output_CoreCount_all_sql1.csv /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv > /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv

sort -t, -nk1,1 -o /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv

sed -i '1i Host,Total,Offline,'$temp_var2'' /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv

sed -i '1i Sr,Date,'$date_var','$temp_var1'' /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv

echo "$total,$total_final" >> /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv

cat /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv > $OUPUTFILECSV1


$MAILX -s "PIAM All_Controllers_offline_by_host daily status trend report $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV1 $MailToList < $Mailbody

cat /home/jioapp/mailoutput/generic/sorted_Output_CoreCount_final.csv > /home/jioapp/mailoutput/generic/Output_CoreCount_orig.csv

