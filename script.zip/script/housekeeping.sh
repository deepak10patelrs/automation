###############################################################################################
# Name       : housekeeping.sh                                                                #
# Description: To purge log/output file older than 30 days                                    #
# Auto Mail  : No                                                                             #
# Author     : Deepak Patel                                                                   #
###############################################################################################


#!/bin/bash

# To move file older than 30 days 

for i in `cat /home/jioapp/sql/slp_config/hk.config`
do
find $i -mtime +30 -type f -exec mv -t /home/jioapp/sql/slp_config/oldlog {} \;
done

# To remove above moved files from /home/jioapp/sql/slp_config/oldlog

cd /home/jioapp/sql/slp_config/oldlog
ls |xargs rm  
