###########################################################################################
# Name       : ControllerOnline.sh		                 		  	  #
# Description: To find controllers offline/online status trendwise report by macid	  #
# Auto Mail  : Yes                                        				  #
# Author     :                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
day=`date +%d`
date_var=`date +%Y%m%d`
date_var1=`date -d "-1 day" +%d-%m-%Y`
date_var2=`date -d "-2 day" +%d-%m-%Y`
date_var3=`date -d "-3 day" +%d-%m-%Y`
date_var4=`date -d "-4 day" +%d-%m-%Y`
date_var5=`date -d "-5 day" +%d-%m-%Y`
date_var6=`date -d "-6 day" +%d-%m-%Y`
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
#OUPUTFILECSV=/home/jioapp/test/"historictrend.csv"
MailToList="priyesh.kumar@ril.com,rahul1.dalvi@ril.com,jaideep.mokha@ril.com,rashmi1.rai@ril.com"

MAILX='mailx'

cat > $Mailbody << EOF
Dear All,

Please find Controllers online and offline Status trend report by $NOW


Regards,
JIONOC IT
EOF


` /usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (Select *,CASE When statecode In('AS','BR','JH','KO','NE','OR','WB') Then 'East' When statecode In ('CG','GO','GJ','MP','MH','MU','RJ') Then 'West' When statecode IN('DL','HR','HP','JK','KS','PB','UE','UW','UA') Then 'North' When statecode IN('AP','KA','KL','TN','TG') Then 'South' Else 'Unknown' End as Region,CASE when statecode ='BR' Then 'Bihar' when statecode ='CG' Then 'Chhattisgarh' when statecode ='DL' Then 'Delhi' when statecode ='GO' Then 'Goa' when statecode ='GJ' Then 'Gujarat' when statecode ='AP' Then 'Andhra Pradesh' when statecode ='HR' Then 'Haryana' when statecode ='AS' Then 'Assam' when statecode ='HP' Then 'Himachal Pradesh'when statecode ='JK' Then 'Jammu' when statecode ='JH' Then 'Jharkhand' when statecode ='KA' Then 'Karnataka' when statecode ='KS' Then 'Kashmir' when statecode ='KL' Then 'Kerala' when statecode ='KO' Then 'Kolkata' when statecode ='MP' Then 'Madhya Pradesh' when statecode ='OR' Then 'Orissa' when statecode ='MH' Then 'Maharashtra' when statecode ='MU' Then 'Mumbai' when statecode ='NE' Then 'NorthEast' when statecode ='PB' Then 'Punjab' when statecode ='RJ' Then 'Rajasthan' when statecode ='TN' Then 'Tamil Nadu' when statecode ='TG' Then 'Telangana' when statecode ='UE' Then 'UttarPradesh(East)' when statecode ='UW' Then 'Uttar Pradesh(West)' when statecode ='UA' Then 'Uttaranchal' when statecode ='WB' Then 'West Bengal' Else 'NUL' End as STATENAME from (select * FROM dblink('dbname=PIAMDB','(select macid,isonline,description,controllerip, sap_id,substring(description,5,4), createdon from piamapp."controllerMaster")')As tb1(macid varchar (40),isonline varchar(20),description varchar(40),controllerip varchar(40),sap_id_orig varchar(40),sap_id varchar(40),createdon timestamp without time zone))as AA left Join (SELECT citycode, statecode,cmp FROM public.city) as D on AA.sap_id = D.citycode)TO '/home/jioapp/mailoutput/generic/Output_offline_testping.csv' WITH CSV HEADER
\copy (select * FROM dblink('dbname=PIAMDB','(select macid,controllerip from piamapp."controllerMaster")')As tb1(macid varchar(40),controllerip varchar(40))) TO '/home/jioapp/mailoutput/generic/rawdata.csv' WITH CSV HEADER
EOF`

sed -i 1d /home/jioapp/mailoutput/generic/Output_offline_testping.csv
#sort -t, -k1,1 /home/jioapp/test/cityjoinfile.csv

awk -F"," '{print $1","$10","$11","$12","$13","$14","$15","$16","$17","$18","$19","$20","$21}' /home/jioapp/test/previousdata.csv > /home/jioapp/test/previousdaydata.csv
sed -i 1d /home/jioapp/test/previousdaydata.csv
sed 1d /home/jioapp/mailoutput/generic/pingstat.csv > /home/jioapp/mailoutput/generic/pingstate.csv
cat /home/jioapp/mailoutput/generic/pingstate.csv|awk -F"," '{print $2,$3}'|sed 's/ /,/g' >$HOME/test/abc.csv

#cat /home/jioapp/mailoutput/generic/Output_offline_testping.csv|awk -F"," '{print $6}'|sed 's/ /,/g' >$
sort -t, -k1,1 /home/jioapp/test/abc.csv > /home/jioapp/test/sorted_abc.csv
sort -t, -k1,1 /home/jioapp/mailoutput/generic/Output_offline_testping.csv > /home/jioapp/test/Output_offline_sorted.csv
#sort -t, -k1,1 /home/jioapp/mailoutput/generic/joinfinal.csv > /home/jioapp/test/sorted_data.csv

#join -t, -2 1 -1 1  /home/jioapp/test/sorted_abc.csv /home/jioapp/test/sorted_data.csv -a 1 > /home/jioapp/test/finaljoin.csv
#join -t, -1 1 -2 1 -a 2 -o 2.1,2.2,2.3,2.4,2.5,2.7,2.9,1.2,2.10,2.11,2.12 /home/jioapp/test/cityjoinfile.csv /home/jioapp/test/Output_offline_sorted.csv > /home/jioapp/test/OutputData.csv
join -t, -1 1 -2 1 -a 2 -o 2.1,2.3,2.4,2.5,2.7,2.9,2.11,2.10,2.12,1.2,2.2 /home/jioapp/test/sorted_abc.csv /home/jioapp/test/Output_offline_sorted.csv > /home/jioapp/test/finaljoint.csv

sort -t, -k1,1 /home/jioapp/test/previousdaydata.csv > /home/jioapp/test/previousdaydata_sorted.csv
join -t, -1 1 -2 1 -a 2 -o 2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,2.10,2.11,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,1.10,1.11,1.12,1.13 /home/jioapp/test/previousdaydata_sorted.csv /home/jioapp/test/finaljoint.csv > /home/jioapp/test/finaljoin.csv


sed -i '1i\Macid,Description,Controllerip,Sap_id,CreatedOn,Statecode,Region,CMP,StateName,PingStatus-'$NOW',isOnline-'$NOW',PingStatus-'$date_var1',Isonline-'$date_var1',PingStatus-'$date_var2',Isonline-'$date_var2',PingStatus-'$date_var3',Isonline-'$date_var3',PingStatus-'$date_var4',Isonline-'$date_var4',PingStatus-'$date_var5',Isonline-'$date_var5',PingStatus-'$date_var6',Isonline-'$date_var6'' /home/jioapp/test/finaljoin.csv
#cat /home/jioapp/test/mailfile.csv|awk -F"," '{$7=$8=$9="";print}'|sed 's/ /,/g' > /home/jioapp/test/mailfile1.csv


cat /home/jioapp/test/finaljoin.csv|uniq > /home/jioapp/test/historictrend_$NOW.csv
cat /home/jioapp/test/historictrend_$NOW.csv > /home/jioapp/test/previousdata.csv
gzip /home/jioapp/test/historictrend_$NOW.csv
fin=/home/jioapp/test/"historictrend_$NOW.csv.gz"
$MAILX -s "Field Visit-Historic controller information for $NOW" -r "jionoc.it@ril.com" -a $fin  $MailToList < $Mailbody

