###########################################################################################
# Name       : euronet_sync_err.sh		                 		  	  #
# Description: It will capture euronet piam card syncup error deatailed view   		  #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################


#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/euronet/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/euronet/"euronet_syncup_err.$NOW.csv"
MailToList="Jaideep.Mokha@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Sankara.Suravaram@ril.com,deepak10.patel@ril.com,sanket.kulkarni@ril.com,jadvinder.singh@ril.com,abhijit1.gaikwad@ril.com,makarand.upadhye@ril.com,Manish.S.Deshmukh@ril.com,Jio.TopsSLPAppSupport@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF

\copy (select * from (select distinct b.cardnumber as piamcard,a.cardnumber as Euronetcard,b.employeeid as piamemployee,a.employeeid as euronetemployee,a.remark,a.logdate,a.facilitycode,a.issuelevel,max(cast(serverdatetime as date)) over (partition by a.cardnumber), min(cast(serverdatetime as date)) over (partition by a.cardnumber) from (select * from (select employeeid, cardnumber, logdate, facilitycode,issuelevel, remark, rank () over (partition by cardnumber order by  logdate desc) as lastdate  from  public.euronetlogs where logdate>NOW() - Interval '1 day' and (remark !='FAILED EURONET SYNC,EXCEPTION' and remark not like'%Error%' and remark not like '%Success%')) X  where  lastdate=1) A  left outer join ( select * from events where serverdatetime > NOW() - Interval'30 days'  and cardnumber in ((select distinct cast (cardnumber as varchar(20))  from  public.euronetlogs where logdate> NOW() - Interval'1 day' and (remark not like '%FAILED%' and remark not like'%Error%' and remark not like '%Success%')))) B on b.cardnumber=cast (a.cardnumber as varchar(20)) ) P left outer join ( SELECT tb2.cardnumber, tb2.employeeid, tb2.facilitycode,tb2.expiry_date, tb2.employeestatus FROM dblink('dbname=PIAMDB','(select distinct cardnumber, employeeid,facilitycode,cast(todate as date), status  from piamapp.mapping_cardholder_card  ) ') AS tb2( cardnumber bigint, employeeid varchar(20), facilitycode varchar(20),expiry_date date, employeestatus varchar(20) )) Q on p.Euronetcard= Q.cardnumber order by Q.cardnumber) TO '/home/jioapp/mailoutput/euronet/euronet_syncup_err.csv' WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/euronet/euronet_syncup_err.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find Euronet Sync up Error $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Euronet Sync up Error $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

