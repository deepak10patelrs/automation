#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/attendance_scheduler_one_hour_count/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/attendance_scheduler_one_hour_count.sh/"Output_CoreCount.$NOW.csv"
MailToList="JioNOC.ITDRSupport@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Sanket.Kulkarni@ril.com,Ritesh.Parekh@ril.com,Deepak10.Patel@ril.com"

MAILX='mailx'

VAL=`/usr/local/pgsql/bin/psql $dbname $username << EOF

select count (*) from attendence_details where serverdatetime >=now()-interval '60 mins'

EOF`

cat > $Mailbody << EOF
Dear All,

Please find the last one hour attendance count on $NOW


$VAL.


Regards,
JIONOC IT
EOF

$MAILX -s "Attendance count for last one hour $NOW" -r "jionoc.it@ril.com"  $MailToList < $Mailbody

