#!/bin/bash
for i in `cat query`
do
. micro.sh $i email.txt
done

