###############################################################################################
# Name       : future_date_controller.sh				      		      #
# Description: Report of PIAM controllers sending future Dates			 	      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/Future_date_controller/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/Future_date_controller/"Output_CoreCount.$NOW.csv"
MailToList="deepak10.patel@ril.com,Sankara.Suravaram@ril.com,Haroon.Ahmed@ril.com,Rahul1.dalvi@ril.com,Jaideep.mokha@ril.com,rashmi1.rai@ril.com,Awadhesh1.Yadav@ril.com,Thisore.Raghu@ril.com,Pranav.M.Vyas@ril.com,Dileep.Deshmukh@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"

MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (select macid,cast(controllerdate as date) , count(*) from (SELECT * FROM public.events where controllerdate > now() and serverdatetime > now() - interval '24 hrs' ) as A group by macid,cast(controllerdate as date) order by controllerdate desc) TO '/home/jioapp/mailoutput/Future_date_controller/Output_CoreCount.csv' With CSV HEADER
EOF`

cat /home/jioapp/mailoutput/Future_date_controller/Output_CoreCount.csv > $OUPUTFILECSV


cat > $Mailbody << EOF
Dear All,

Please find the PIAM controllers with Future Dates Report $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "PIAM controllers with Future Dates $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

