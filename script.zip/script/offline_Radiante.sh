###############################################################################################
# Name       : offline_Radiante.sh			       		      		      #
# Description: To find which all radiante controllers are offline			      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/Offline_Radiante/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/Offline_Radiante/"Output_CoreCount.$NOW.csv"
MailToList="Sankara.Suravaram@ril.com,deepak10.patel@ril.com,Jaideep.Mokha@ril.com,Awadhesh1.Yadav@ril.com,Thisore.Raghu@ril.com,Jignesh.Purohit@ril.com,Saurabh.Bhatnagar@ril.com,Rahul1.Dalvi@ril.com,Rashmi1.Rai@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"

MAILX='mailx'
`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (SELECT controllerip, id_controller, macid FROM piamapp."controllerMaster" where  id_oem='1' and isonline='f') TO '/home/jioapp/mailoutput/Offline_Radiante/Output_CoreCount.csv' With CSV HEADER
EOF`

cat /home/jioapp/mailoutput/Offline_Radiante/Output_CoreCount.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find Today's Offline_Radiante_Controllers Status  $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Offline Radiante Controllers Status $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

