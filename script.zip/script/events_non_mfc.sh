#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/acs_core_server_count/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"Output_CoreCount_nonmfc.$NOW.csv"
MailToList="Slp.operationscontrol@zmail.ril.com,Amarsingh.Gharge@ril.com,Sunil.Pangul@ril.com,Mohsin.Tamboli@zmail.ril.com,nilesh.ghodke@ril.com,Jaideep.Mokha@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Sankara.Suravaram@ril.com,deepak10.patel@ril.com,sanket.kulkarni@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (select distinct cardnumber,employeeid,facilitycode,eventname,macid, count(*) from (SELECT  macid, idalarm,  controllerdate, serverdatetime,cardnumber, issuelevel, id_location, eventname, locationname,id_timezone, employeeid, employeename, facilitycode FROM public.events where serverdatetime > NOW()- Interval '1 Day'  ) A group by A.eventname,cardnumber,macid,employeeid,facilitycode having eventname  in('ENTRY GRANTED','EXIT GRANTED','CARD SWIPED DENIED IN','CARD SWIPED DENIED OUT','ANTI PASS BACK DENIED IN', 'ANTI PASS BACK DENIED OUT','CARD SWIPED FAC DENIED IN','CARD SWIPED FAC DENIED OUT', 'ENTRY NOT TAKEN','EXIT NOT TAKEN  ','WRONG CARD TIME','LOST CARD','UNKNOWN CARD','CARD ISSUE LEVEL MISMATCH ', 'HID_ACCESS_DENY_CARD_DELETED_IN','HID_ACCESS_DENY_NOT_ACTIVE ', 'HID_ACCESS_DENY_CARD_DELETED_OUT','HID_ACCESS_DENY_NOT_ACTIVE_OUT') and cardnumber in ( SELECT tb2.cardnumber FROM   dblink('dbname=PIAMDB','select cardnumber from (select distinct cardnumber, employeeid from piamapp.mapping_cardholder_card where status=1 and (employeeid similar to ''[0-9]*'' ) )as A group by cardnumber having count(*) >1') AS tb2(cardnumber varchar(20)) ) and macid  in (SELECT tb3.macid FROM   dblink('dbname=PIAMDB','SELECT description, id_oem, firmwareversion, macid, controllerip,id_host, isonline,  sap_id  FROM piamapp."controllerMaster" where id_host not in (40,72,43)') AS tb3 (description text, id_oem text, firmwareversion text, macid text, controllerip text,id_host text, isonline text,  sap_id text))  order by count(*) desc) TO '/home/jioapp/mailoutput/generic/Output_CoreCount_nonmfc.csv' WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/generic/Output_CoreCount.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find report of Events from NON MFC $NOW.

For more details go through the attachment.

Regards,
JIONOC IT
EOF

$MAILX -s "EVENTS FROM NON-MFC" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody



