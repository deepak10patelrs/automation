###############################################################################################
# Name       : All_Controller_Status.sh			    		      		      #
# Description: To find All Controllers Status online/offline based on OEM		      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/All_Controller_Status/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/All_Controller_Status/"Output_CoreCount.$NOW.csv"
MailToList="sankara.suravaram@ril.com,deepak10.patel@ril.com,Jaideep.Mokha@ril.com,Awadhesh1.Yadav@ril.com,Thisore.Raghu@ril.com,Jignesh.Purohit@ril.com,Saurabh.Bhatnagar@ril.com,Rahul1.Dalvi@ril.com,Rashmi1.Rai@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"

MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (SELECT id_oem, isonline ,  count(*) FROM piamapp."controllerMaster" group by id_oem, isonline having isonline='f' order by id_oem) TO '/home/jioapp/mailoutput/All_Controller_Status/Output_CoreCount.csv' WITH CSV HEADER
EOF`

cat /home/jioapp/mailoutput/All_Controller_Status/Output_CoreCount.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find the Controllers Status  $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "All Controllers Status $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody


