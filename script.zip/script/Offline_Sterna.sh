###############################################################################################
# Name       : Offline_Sterna.sh			    		      		      #
# Description: To find which all sterna controllers are offline				      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/Offline_Sterna/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/Offline_Sterna/"Output_CoreCount.$NOW.csv"
MailToList="Sankara.Suravaram@ril.com,deepak10.patel@ril.com,Jaideep.Mokha@ril.com,Awadhesh1.Yadav@ril.com,Thisore.Raghu@ril.com,Jignesh.Purohit@ril.com,Saurabh.Bhatnagar@ril.com,Rahul1.Dalvi@ril.com,Rashmi1.Rai@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (SELECT  controllerip, id_controller, macid FROM piamapp."controllerMaster" where  id_oem='2' and isonline='f') To '/home/jioapp/mailoutput/Offline_Sterna/Output_CoreCount.csv' With CSV HEADER
EOF`

cat /home/jioapp/mailoutput/Offline_Sterna/Output_CoreCount.csv > $OUPUTFILECSV
cat > $Mailbody << EOF
Dear All,

Please find Today's Offline_Sterna_Controllers Status  $NOW

For more details go through the attachment.


Regards,
JIONOC IT
EOF

$MAILX -s "Offline_Sterna_Controllers Status" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

