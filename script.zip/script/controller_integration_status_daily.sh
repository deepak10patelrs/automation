###########################################################################################
# Name       : controller_integration_status_daily.sh                  		  	  #
# Description: To find controllers added in last 24 hours				  #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"output_integration_status_day.$NOW.csv"
MailToList="Shakti.Sharma@ril.com,Vikas.Madhok@ril.com,Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Saurabh.Bhatnagar@ril.com,Jignesh.Purohit@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Sonali.Dubale@ril.com,Shalini.Jaiswal@ril.com,Govind.M.Mishra@ril.com,Raj18.Singh@ril.com,Jio.TopsSLPAppSupport@ril.com,rjilsecurity.operationscentre@ril.com,Manish.Sondhi@ril.com,Sanket.Kulkarni@ril.com,Girish.Juneja@ril.com"
#MailToList="deepak10.patel@ril.com" 
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF

\copy (Select * from (select * FROM dblink('dbname=PIAMDB','(select description,controllerip,macid,sap_id,substring(sap_id,6,4),firmwareversion,id_oem,controlleriptype,createdon,createdby,isonline from piamapp."controllerMaster" where createdon>NOW()- Interval ''1 day'')')As tb1(description varchar(40),controllerip varchar(40),macid varchar(40),sap_id_orig varchar(40),sap_id varchar(40),firmwareversion varchar(40),id_oem integer,controlleriptype integer,createdon timestamp without time zone,createdby varchar(100),isonline varchar(20)))as AA left join (SELECT cityname,citycode,statecode,state_name,cmp FROM public.city) as C on AA.sap_id=C.citycode) TO '/home/jioapp/mailoutput/generic/output_integration_day.csv'  WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/generic/output_integration_day.csv> $OUPUTFILECSV

count=`cat /home/jioapp/mailoutput/generic/output_integration_day.csv|awk -F "," '{print $1}'|sed '/^$/d'|grep -oP '\b[A-Z0-9_]+\b'|wc -l`

#count=`cat /home/jioapp/mailoutput/generic/output_integration_day.csv|grep ^IN|wc -l`

cat > $Mailbody << EOF
Dear All,

The count of Daily New Integration added is $count till $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Daily New Integration Status $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody
