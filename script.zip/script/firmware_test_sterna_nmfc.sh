#########################################################################################
# Name       : firmware_test_sterna_nmfc.sh        		                        #
# Description: Firmware upgrade testing report for Non-MFC Sterna Two Reader controllers#
# Auto Mail  : Yes                                                          		#
# Author     : Deepak Patel                                                 		#
#########################################################################################


#dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
#MailToList="deepak10.patel@ril.com" 
MailToList="Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Sanket.Kulkarni@ril.com,Jaideep.Mokha@ril.com,Awadhesh1.Yadav@ril.com,Jio.TopsSLPAppSupport@ril.com,thisore.raghu@zmail.ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
Mailbody=/home/jioapp/mailoutput/generic/sterna/MAILBODY
MAILX='mailx'
#rtc=`tr -d '\n'< /home/jioapp/config/macid.txt`
rtc2=`tr -d '\n'< /home/jioapp/config/macid_nmfc.txt`

cat > $Mailbody << EOF
Dear All,

Please find the attached testing report for Non-MFC Sterna Two Reader controller firmware upgrade $NOW

Regards,
JIONOC IT
EOF

################################################### Alarm Query  ######################################################################################################
#OUPUTFILECSV=/home/jioapp/mailoutput/high_controller_events/"alarm_firmware.$NOW.csv"

`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF

\copy (SELECT rowid, alarmid, macid, idalarm, controllerdatetime,serverdatetime,alarmdiscription, alarmname,sap_id,facilitycode,doorid FROM public.livealarmshistory where serverdatetime> NOW()- Interval '4 hrs' and idalarm IN('56','100','24','39','38','162') and macid IN ($rtc2) order by macid) TO '/home/jioapp/mailoutput/generic/sterna/alarm_firmware.csv' WITH CSV HEADER
EOF`

output1=/home/jioapp/mailoutput/generic/sterna/alarm_firmware.csv

############################################ Controller online and offline ###############################################################################

`/usr/local/pgsql/bin/psql "PIAMDB" $username << EOF

\copy (SELECT a.description as NEID,a.macid,a.controllerip,a.id_host,a.lastheartbeat,a.isonline as onlinestatus,a.sap_id,b.hostip1 as remoteserve1,b.hostip2 as remoteserver2,b.hostip3 as remoteserver3, a.id_oem, a.firmwareversion,a.gatewayip FROM piamapp."controllerMaster" a inner join piamapp."hostMaster" b ON a.id_host=b.id_host where macid IN ($rtc2)) TO '/home/jioapp/mailoutput/generic/sterna/cntrl_online_offline.csv' WITH CSV HEADER
EOF`

output2=/home/jioapp/mailoutput/generic/sterna/cntrl_online_offline.csv

######################################### Device with bulk alarms ####################################################################################################

`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF
\copy (select macid,idalarm,alarmname,count(*)  FROM public.livealarmshistory where serverdatetime> NOW()- Interval '4 hrs' and macid IN ($rtc2) group by macid,idalarm,alarmname order by count(*) desc) TO '/home/jioapp/mailoutput/generic/sterna/bulk_alarm.csv' WITH CSV HEADER 
EOF`

output3=/home/jioapp/mailoutput/generic/sterna/bulk_alarm.csv

#############################################Device with bulk events #################################################################################################


`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF
\copy (select macid,idalarm,eventname,count(*)  FROM public.events where serverdatetime> NOW()- Interval '4 hrs' and macid IN($rtc2) group by macid,idalarm,eventname order by count(*) desc) TO '/home/jioapp/mailoutput/generic/sterna/bulk_events.csv' WITH CSV HEADER
EOF`

output4=/home/jioapp/mailoutput/generic/sterna/bulk_events.csv

######################################## Event Query ###############################################################################################################

`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF

\copy (SELECT eventid, macid, idalarm,controllerdate,serverdatetime,cardnumber, issuelevel, eventname, alarmdiscription,sap_id, employeeid, employeename, facilitycode, doorid FROM public.events where serverdatetime> NOW()- Interval '4 hrs' and idalarm IN ('4','1','2','130','9','16','161','32','3','81','82','128','129','71','165','164','224','200','223','101') and macid IN ($rtc2)) TO '/home/jioapp/mailoutput/generic/sterna/event_query.csv'  WITH CSV HEADER
EOF`

output5=/home/jioapp/mailoutput/generic/sterna/event_query.csv

###########################################################  Future Date events ##############################################################################

`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF
\copy (select macid,cast(controllerdate as date),count(*) from (SELECT * FROM public.events where controllerdate > now() and serverdatetime>NOW()- Interval '24 hrs' and macid IN($rtc2)) as A group by macid,cast(controllerdate as date) order by controllerdate desc) TO '/home/jioapp/mailoutput/generic/sterna/futuredate_events.csv' WITH CSV HEADER
EOF`

output6=/home/jioapp/mailoutput/generic/sterna/futuredate_events.csv
###################################################### HIGH ALARMS ################################################################################################

`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF
\copy (select macid,sap_id,count(*) from (select * from livealarmshistory where serverdatetime>NOW()-Interval '4 hrs' and macid IN ($rtc2)) A group by macid,sap_id having count(*)>1000 order by count(*) desc) TO '/home/jioapp/mailoutput/generic/sterna/high_alarms.csv' WITH CSV HEADER
EOF`

output7=/home/jioapp/mailoutput/generic/sterna/high_alarms.csv

###################################################### HIGH EVENTS ################################################################################################

`/usr/local/pgsql/bin/psql "PIAM_TRANS_DB" $username << EOF
\copy (select macid,sap_id,count(*) from (select * from events where serverdatetime>NOW()- Interval '4 hrs' and macid IN ($rtc2)) A group by macid,sap_id having count(*)>1000 order by count(*) desc) TO '/home/jioapp/mailoutput/generic/sterna/high_events.csv' WITH CSV HEADER
EOF`

output8=/home/jioapp/mailoutput/generic/sterna/high_events.csv

######################################### To SEND MAIL ######################################################

$MAILX -s "Firmware upgrade for Non-MFC Sterna Two Reader $NOW" -r "jionoc.it@ril.com" -a $output1 -a $output2 -a $output3 -a $output4 -a $output5 -a $output6 -a $output7 -a $output8 $MailToList < $Mailbody
