###############################################################################################
# Name       : hid_count.sh   			                                              #
# Description: Report 0f HID Core Server Count For Last One Hour                              #
# Auto Mail  : Yes                                                                            #
# Author     : Deepak Patel                                                                   #
###############################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/acs_core_server_onehour_count/MAILBODY
Mailbody1=/home/jioapp/mailoutput/acs_core_server_onehour_count/MAILBODY1
OUPUTFILECSV=/home/jioapp/mailoutput/acs_hid_core_server_onehour_count/"HID_ACS_HOURLY_COUNT.$NOW.csv"
HIDPATH=/home/jioapp/mailoutput/acs_hid_core_server_onehour_count
MailToList="JioNOC.ITDRSupport@ril.com,Jio.TopsSLPAppSupport@ril.com"
#MailToList="deepak10.patel@ril.com"
MAILX='mailx'


`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (WITH t1 as (select a.id_host,count(eventid) totalevents from events,(select t1.macid,t1.id_host  from dblink('port=5432 dbname=PIAMDB',     'select lower(macid),id_host from piamapp."controllerMaster"') as t1(macid character varying,id_host integer)) a where lower(events.macid)=a.macid and serverdatetime>=now()-interval '1 hour' group by a.id_host) select sum(case when id_host=2 then totalevents else 0 end) as count_10_137_2_123,sum(case when id_host=3 then totalevents else 0 end) as count_10_137_2_96,sum(case when id_host=4 then totalevents else 0 end) as count_10_137_2_97,sum(case when id_host=7 then totalevents else 0 end) as count_10_204_185_140,sum(case when id_host=11 then totalevents else 0 end) as count_10_137_12_35,sum(case when id_host=12 then totalevents else 0 end) as count_10_204_195_142__10_148_64_12,sum(case when id_host=23 then totalevents else 0 end) as count_10_137_144_54,sum(case when id_host=46 then totalevents else 0 end) as count_10_137_144_78,sum(case when id_host=47 then totalevents else 0 end) as count_10_137_2_67,sum(case when id_host=70 then totalevents else 0 end) as count_10_137_144_161,sum(case when id_host=71 then totalevents else 0 end) as count_10_137_144_162   from t1) TO '/home/jioapp/mailoutput/acs_hid_core_server_onehour_count/ACS_HID_COUNT.csv' WITH CSV HEADER
EOF`


head -1 $HIDPATH/ACS_HID_COUNT.csv > $HIDPATH/tempfile1

tail -1 $HIDPATH/ACS_HID_COUNT.csv > $HIDPATH/tempfile2

sed -i -e 's/,/\n/g' $HIDPATH/tempfile1 

sed -i -e 's/,/\n/g' $HIDPATH/tempfile2

paste -d" " $HIDPATH/tempfile1 $HIDPATH/tempfile2 > $HIDPATH/tempfile3

sed -i -e 's/ /,/g' $HIDPATH/tempfile3

sed -i '1i Server IP,Count' $HIDPATH/tempfile3


cat $HIDPATH/tempfile3 > $OUPUTFILECSV


cat > $Mailbody << EOF
Dear All,

Please check report as zero count observed for HID server on $NOW.

For more details go through the attachment.

Regards,
JIONOC IT
EOF


#$MAILX -s "HID Server Count For Last One Hour" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

for i in `cat $HIDPATH/tempfile3|awk -F"," '{print $2}'|sed 1d` 
do
if [ $i -eq 0 ];
then
#$MAILX -s "Zero count for HID server" -r "jionoc.it@ril.com" $MailToList < $Mailbody1
$MAILX -s "HID Server Zero Count For Last One Hour" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody
fi
done
