###############################################################################################
# Name       : critical_controller_transdb.sh				      		      #
# Description: To capture event lost card, unknown card and issue level card 	 	      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
for i in `cat /home/jioapp/sql/file_config_transdb`
do 
query=`echo $i|awk -F "," '{print $1}'`
dl=`echo $i|awk -F "," '{print $2}'`
mailbody=`echo $i|awk -F "," '{print $3}'`
subject=`echo $i|awk -F "," '{print $4}'`

. /home/jioapp/sql/master_script_transdb.sh $query $dl $mailbody $subject 
done
