dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
EVENTPATH=/home/jioapp/mailoutput/high_controller_events/
Mailbody=$EVENTPATH/MAILBODY
OUPUTFILECSV=$EVENTPATH/"Output_CoreCount.$NOW.csv"
#MailToList="JioNOC.ITDRSupport@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Ritesh.Parekh@ril.com,Sanket.Kulkarni@ril.com,Rahul1.Dalvi@ril.com,Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Awadhesh1.Yadav@ril.com,Thisore.Raghu@ril.com,Jignesh.Purohit@ril.com,Saurabh.Bhatnagar@ril.com,Omprakash.Tiwari@ril.com,deepak10.patel@ril.com,Jio.TopsSLPAppSupport@ril.com"
MailToList="deepak10.patel@ril.com"

MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF

\copy (Select *,CASE When state_name In('Assam','Bihar','Jharkhand','Kolkata','NorthEast','Orissa','West Bengal') Then 'East' When state_name In ('Chhattisgarh','Goa','Gujarat','Madhya Pradesh','Maharashtra','Mumbai','Rajasthan') Then 'West' When state_name IN('Delhi','Haryana','Himachal Pradesh','Jammu','Kashmir','Punjab','Uttar Pradesh (East)','Uttar Pradesh (West)','Uttar Pradesh (West)','Uttaranchal') Then 'North'  When state_name IN('Andhra Pradesh','Karnataka','Kerala','Tamil Nadu','Telangana') Then 'South' Else 'Unknown' End as Region from (select * from (select macid ,alarmdiscription,sap_id,substring(sap_id,6,4),count(*)  from (select  * from events where serverdatetime  > now()-interval '1 day') A group by macid,alarmdiscription,sap_id having  count(*)  > 1000 order by count(*) desc) as AA left  join (SELECT  cityname, citycode, statecode, state_name, cmp  FROM public.city) as B on AA.substring = B.citycode ) as CC) TO '$EVENTPATH/Output_CoreCount.csv' WITH CSV HEADER

EOF`

cat $EVENTPATH/Output_CoreCount.csv > $OUPUTFILECSV


`cat $EVENTPATH/Output_CoreCount.csv|grep -i "north$" > $EVENTPATH/north_temp.csv`
`cat $EVENTPATH/Output_CoreCount.csv|grep -i "south$" > $EVENTPATH/south_temp.csv`
`cat $EVENTPATH/Output_CoreCount.csv|grep -i "east$" > $EVENTPATH/east_temp.csv`
`cat $EVENTPATH/Output_CoreCount.csv|grep -i "west$" > $EVENTPATH/west_temp.csv`
`cat $EVENTPATH/Output_CoreCount.csv|grep -i "unknown$" > $EVENTPATH/unknown_temp.csv`

cat <(head -1 $EVENTPATH/Output_CoreCount.csv) $EVENTPATH/north_temp.csv > $EVENTPATH/north_final.csv
cat <(head -1 $EVENTPATH/Output_CoreCount.csv) $EVENTPATH/south_temp.csv > $EVENTPATH/south_final.csv
cat <(head -1 $EVENTPATH/Output_CoreCount.csv) $EVENTPATH/east_temp.csv > $EVENTPATH/east_final.csv
cat <(head -1 $EVENTPATH/Output_CoreCount.csv) $EVENTPATH/west_temp.csv > $EVENTPATH/west_final.csv
cat <(head -1 $EVENTPATH/Output_CoreCount.csv) $EVENTPATH/unknown_temp.csv > $EVENTPATH/unknown_final.csv

cat $EVENTPATH/north_final.csv|sort -n -t ',' -k5 -r > $EVENTPATH/north.csv
cat $EVENTPATH/south_final.csv|sort -n -t ',' -k5 -r > $EVENTPATH/south.csv
cat $EVENTPATH/east_final.csv|sort -n -t ',' -k5 -r > $EVENTPATH/east.csv
cat $EVENTPATH/west_final.csv|sort -n -t ',' -k5 -r > $EVENTPATH/west.csv
cat $EVENTPATH/unknown_final.csv|sort -n -t ',' -k5 -r > $EVENTPATH/unknown.csv

output1=$EVENTPATH/north.csv
output2=$EVENTPATH/south.csv
output3=$EVENTPATH/east.csv
output4=$EVENTPATH/west.csv
output5=$EVENTPATH/unknown.csv




cat > $Mailbody << EOF
Dear All,

Please find the high events from controllers on $NOW



Regards,
JIONOC IT
EOF

$MAILX -s "Controllers with high events $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV -a $output1 -a $output2 -a $output3 -a $output4 -a $output5  $MailToList < $Mailbody

