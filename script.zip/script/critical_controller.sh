###############################################################################################
# Name       : critical_controller.sh			    		      		      #
# Description: Details of controllers mapped at critical location 			      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
for i in `cat /home/jioapp/sql/file_config`
do 
query=`echo $i|awk -F "," '{print $1}'`
dl=`echo $i|awk -F "," '{print $2}'`
mailbody=`echo $i|awk -F "," '{print $3}'`
subject=`echo $i|awk -F "," '{print $4}'`

. /home/jioapp/sql/master_script.sh $query $dl $mailbody $subject 
done
