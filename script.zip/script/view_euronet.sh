###########################################################
# Name       : Euronet_sync.sh                            #
# Description: PIAM Euronet Sync up Error Report          #
# Auto Mail  : Yes                                        #
# Author     : Deepak Patel                               #
###########################################################

#!/bin/bash

Mailbody=/home/jioapp/mailoutput/euronet/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/euronet/view_sync.csv
MailToList="jadvinder.singh@ril.com,abhijit1.gaikwad@ril.com,Manish.S.Deshmukh@ril.com,Jio.TopsSLPAppSupport@ril.com"

MAILX='mailx'

#cat /home/jioapp/mailoutput/euronet/euronet_syncup_errlog.csv|grep "FAILED EURONET SYNC" > /home/jioapp/mailoutput/euronet/view_sync.csv

cat /home/jioapp/mailoutput/euronet/euronet_syncup_errlog.csv|grep "Employee already deactived" > /home/jioapp/mailoutput/euronet/view_sync.csv

sed -i -e '1i employeeid,cardnumber,remark,logdate,issuelevel,facilitycode,oldfacilitycode' /home/jioapp/mailoutput/euronet/view_sync.csv

cat > $Mailbody << EOF
Dear All,

Please provide view against following attached card.


Regards,
JIONOC IT
EOF

$MAILX -s "Euronet View against Sync up Error cards $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody
