###########################################################################
# Name       : PIAM_table_bkp.sh        			          #
# Description: To take backup of 6 PIAM tables before deletion activity   #
# Auto Mail  : Yes                                        		  #
# Author     : Deepak Patel                               		  #
###########################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (select * from piamapp.mapping_cardholder_card) To '/home/jioapp/piamdata_bkp/mapping_cardholder_card_$NOW.csv' With CSV HEADER

\copy (select * from piamapp.mapping_cardholder_door) To '/home/jioapp/piamdata_bkp/mapping_cardholder_door_$NOW.csv' With CSV HEADER

\copy (select * from piamapp.mapping_cardholder_acclvl) To '/home/jioapp/piamdata_bkp/mapping_cardholder_acclvl_$NOW.csv' With CSV HEADER

\copy (select * from piamapp."cardMaster") To '/home/jioapp/piamdata_bkp/cardMaster_$NOW.csv' With CSV HEADER

\copy (select * from piamapp.corecarddetails) To '/home/jioapp/piamdata_bkp/corecarddetails_$NOW.csv' With CSV HEADER

\copy (select * from piamapp.cardholders) To '/home/jioapp/piamdata_bkp/cardholders_$NOW.csv' With CSV HEADER

EOF`
