###############################################################################################
# Name       : macid_events_greater_than_serverdatetime.sh     		      		      #
# Description: Controller generating events of future date which a kind of device issue       #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/macid_events_greater_than_serverdatetime/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/macid_events_greater_than_serverdatetime/"output.$NOW.txt"
MailToList="dileep.deshmukh@ril.com,pranav.m.vyas@ril.com,sanket.kulkarni@ril.com,makarand.upadhye@ril.com,JioNOC.ITDRSupport@ril.com,gopal.kulkarni@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
MAILX='mailx'
cat > $Mailbody << EOF
Dear All,

Please find the Today Query count on $NOW.

For more details go through the attachment.

Regards,
JIONOC IT
EOF

VAL=`/usr/local/pgsql/bin/psql $dbname $username << EOF
SELECT DISTINCT macid FROM public.attendence_details
       WHERE date_trunc('hour', serverdatetime::timestamp)=date_trunc('hour', TIMESTAMP 'now()')
AND	DATE_PART('day', eventdate::timestamp - serverdatetime::timestamp) * 24 + 
               DATE_PART('hour', eventdate::timestamp - serverdatetime::timestamp) * 60 +
               DATE_PART('minute', eventdate::timestamp - serverdatetime::timestamp) >5 
AND inout in(1,2) 
AND oem_id in(4,5,6,8,9);
EOF`
# echo "$VAL"
CHECK=`echo "$VAL" | grep '0 rows'`
# echo "$CHECK"
if [ ! -z "$CHECK" ];then
echo "No records found"
exit 0
else
echo $VAL > $OUPUTFILECSV
$MAILX -s "Macid details for events greater than serverdatetime on $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody
fi

