#!/bin/bash

###############################################################################################
# Name       : high_controller_events_regional.sh	       		      		      #
# Description: To find controllers generating high event for DFO,DHO on Regional basis	      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/high_controller_events/MAILBODY
MAILX='mailx'

cat > $Mailbody << EOF
Dear All,

Please find the high events from controllers for regions on $NOW

Regards,
JIONOC IT
EOF

for i in `cat /home/jioapp/test/states.txt`
do
cat /home/jioapp/mailoutput/high_controller_events/Output_CoreCount.csv|awk -F"," '$8=="'$i'"' > /home/jioapp/test/"$i.csv" 
sed -i '1imacid,alarmdiscription,sap_id,substring,count,cityname,citycode,statecode,state_name,cmp,region' /home/jioapp/test/"$i.csv"
OUPUTFILECSV=/home/jioapp/mailoutput/high_controller_events/"High_Events_$i.csv"
cat /home/jioapp/test/"$i.csv" > $OUPUTFILECSV
grep ^$i /home/jioapp/test/mailfile.txt|awk -F"," '{print $3,$4,$5}'|sed 's/ /,/g'>/home/jioapp/test/tempmail_to.txt

MailToList=`cat /home/jioapp/test/tempmail_to.txt`

MailccList=`cat /home/jioapp/test/tempmail_cc.txt`

$MAILX -s "Controllers with high events for regions $NOW- TESTING" -r "jionoc.it@ril.com" -a $OUPUTFILECSV -c $MailccList $MailToList < $Mailbody
sleep 2
done
