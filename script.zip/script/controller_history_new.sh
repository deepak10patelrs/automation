###########################################################################################
# Name       : online_offline.sh		                 		  	  #
# Description: To find controllers offline/online status trendwise report by macid	  #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
day=`date +%d`
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"output_status.$day.csv"
MailToList="Rahul1.Dalvi@ril.com,Priyesh.Kumar@ril.com"


MAILX='mailx'

cat > $Mailbody << EOF
Dear All,

Please find Controllers online and offline Status trend report by macid $NOW


Regards,
JIONOC IT
EOF

temp_date=`head -1 /home/jioapp/mailoutput/generic/last_days_data.csv|awk -F"," '{ for (i=2; i<=NF; i++) print $i }'|paste -sd","`

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (Select *,CASE When state_name In('Assam','Bihar','Jharkhand','Kolkata','NorthEast','Orissa','West Bengal') Then 'East' When state_name In ('Chhattisgarh','Goa','Gujarat','Madhya Pradesh','Maharashtra','Mumbai','Rajasthan') Then 'West' When state_name IN('Delhi','Haryana','Himachal Pradesh','Jammu','Kashmir','Punjab','Uttar Pradesh (East)','Uttar Pradesh (West)','Uttaranchal') Then 'North' When state_name IN('Andhra Pradesh','Karnataka','Kerala','Tamil Nadu','Telangana') Then 'South' Else 'Unknown' End as Region  from (select * FROM dblink('dbname=PIAMDB','(select description,controllerip,macid, sap_id,substring(sap_id,6,4), firmwareversion,id_oem, controlleriptype,createdon,createdby,isonline from piamapp."controllerMaster" where createdon>NOW()- Interval ''1 day'')')As tb1(description varchar(40),controllerip varchar(40),macid varchar(40),sap_id_orig varchar(40),sap_id varchar(40),firmwareversion varchar(40),id_oem integer,controlleriptype integer,createdon timestamp without time zone,createdby varchar(100),isonline varchar(20)))as  AA left join (SELECT  cityname, citycode, statecode, state_name, cmp  FROM public.city) as D on AA.sap_id = D.citycode") TO '/home/jioapp/mailoutput/generic/Output_offline.csv' WITH CSV HEADER 
EOF`

`sed 1d /home/jioapp/mailoutput/generic/last_days_data.csv > /home/jioapp/mailoutput/generic/last_days_data1.csv`
`sed 1d /home/jioapp/mailoutput/generic/Output_offline.csv > /home/jioapp/mailoutput/generic/output1.csv`

sort -k1 /home/jioapp/mailoutput/generic/last_days_data1.csv > /home/jioapp/mailoutput/generic/last_days_data1_sorted.csv
sort -k1 /home/jioapp/mailoutput/generic/output1.csv > /home/jioapp/mailoutput/generic/output1_sorted.csv

join -t, -1 1 -2 1 -a 2 -o 2.1,2.2,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,1.10,1.11,1.12,1.13,1.14,1.15,1.16,1.17,1.18,1.19,1.20,1.21,1.22,1.23,1.24,1.25,1.26,1.27,1.28,1.29,1.30 /home/jioapp/mailoutput/generic/last_days_data1_sorted.csv /home/jioapp/mailoutput/generic/output1_sorted.csv > $OUPUTFILECSV

#join -t, -1 1 -2 1 /home/jioapp/mailoutput/generic/last_days_data1_sorted.csv /home/jioapp/mailoutput/generic/output1_sorted.csv -a 1 > $OUPUTFILECSV

#Date Variable

date_var=`date +%Y/%m/%d`

#sed -i -e '1i macid,description,controllerip'$date_var','$date_var1','$date_var2','$date_var3','$date_var4','$date_var5','$date_var6','$date_var7','$date_var8','$date_var9','$date_var10'' $OUPUTFILECSV

sed -i -e '1i macid,'$date_var','$temp_date'' $OUPUTFILECSV

`gzip $OUPUTFILECSV`

final=/home/jioapp/mailoutput/generic/"output_status.$day.csv.gz"

$MAILX -s "Field Visit-Historic controller information for $NOW" -r "jionoc.it@ril.com" -a $final $MailToList < $Mailbody

gunzip $final

`cat /home/jioapp/mailoutput/generic/"output_status.$day.csv" > /home/jioapp/mailoutput/generic/last_days_data.csv`
