###########################################################################################
# Name       : online_offline.sh		                 		  	  #
# Description: To find controllers offline/online status trendwise report by macid	  #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
day=`date +%d`
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"output_status.$day.csv"
#MailToList="Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Jio.TopsSLPAppSupport@ril.com,Jignesh.Purohit@ril.com,Pranav.M.Vyas@ril.com,Dileep.Deshmukh@ril.com,Saurabh.Bhatnagar@ril.com,Vikas.Madhok@ril.com,Shalini.Jaiswal@ril.com,Govind.M.Mishra@ril.com,Girish.Juneja@ril.com,Amiya2.Panda@ril.com,Sanjeev4.Singh@ril.com,Vinay.Dubey@ril.com,Aparnesh.Mitra@ril.com,Dharmendra1.Shukla@ril.com,Ambuj1.Sharma@ril.com"
MailToList="deepak10.patel@ril.com"

MAILX='mailx'

cat > $Mailbody << EOF
Dear All,

Please find Controllers online and offline Status trend report by macid $NOW


Regards,
JIONOC IT
EOF

temp_date=`head -1 /home/jioapp/mailoutput/generic/last_days_data.csv|awk -F"," '{ for (i=2; i<=NF; i++) print $i }'|paste -sd","`

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (select macid,isonline from piamapp."controllerMaster") TO '/home/jioapp/mailoutput/generic/Output_offline.csv' WITH CSV HEADER
EOF`

`sed 1d /home/jioapp/mailoutput/generic/last_days_data.csv > /home/jioapp/mailoutput/generic/last_days_data1.csv`
`sed 1d /home/jioapp/mailoutput/generic/Output_offline.csv > /home/jioapp/mailoutput/generic/output1.csv`

sort -k1 /home/jioapp/mailoutput/generic/last_days_data1.csv > /home/jioapp/mailoutput/generic/last_days_data1_sorted.csv
sort -k1 /home/jioapp/mailoutput/generic/output1.csv > /home/jioapp/mailoutput/generic/output1_sorted.csv

join -t, -1 1 -2 1 -a 2 -o 2.1,2.2,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,1.10,1.11,1.12,1.13,1.14,1.15,1.16,1.17,1.18,1.19,1.20,1.21,1.22,1.23,1.24,1.25,1.26,1.27,1.28,1.29,1.30 /home/jioapp/mailoutput/generic/last_days_data1_sorted.csv /home/jioapp/mailoutput/generic/output1_sorted.csv > $OUPUTFILECSV

sort -u $OUPUTFILECSV -o $OUPUTFILECSV

#join -t, -1 1 -2 1 /home/jioapp/mailoutput/generic/last_days_data1_sorted.csv /home/jioapp/mailoutput/generic/output1_sorted.csv -a 1 > $OUPUTFILECSV

#Date Variable

date_var=`date +%Y/%m/%d`

#sed -i -e '1i macid,'$date_var','$date_var1','$date_var2','$date_var3','$date_var4','$date_var5','$date_var6','$date_var7','$date_var8','$date_var9','$date_var10'' $OUPUTFILECSV

sed -i -e '1i macid,'$date_var','$temp_date'' $OUPUTFILECSV

`gzip $OUPUTFILECSV`

final=/home/jioapp/mailoutput/generic/"output_status.$day.csv.gz"

$MAILX -s "Field Visit-Historic controller information for $NOW" -r "jionoc.it@ril.com" -a $final $MailToList < $Mailbody

gunzip $final

`cat /home/jioapp/mailoutput/generic/"output_status.$day.csv" > /home/jioapp/mailoutput/generic/last_days_data.csv`

