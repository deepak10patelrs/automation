###############################################################################################
# Name       : acs_core_server_onehour_count.sh		       		      		      #
# Description: Report 0f ACS Core Server Count For Last One Hour			      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/acs_core_server_onehour_count/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/acs_core_server_onehour_count/"ACS_HOURLY_COUNT.$NOW.csv"
MailToList="Jio.TopsSLPAppSupport@ril.com,JioNOC.ITDRSupport@ril.com"
#cc_list="JioNOC.ITDRSupport@ril.com"
MAILX='mailx'


`/usr/local/pgsql/bin/psql $dbname $username << EOF 
\copy (WITH t1 as      (select a.id_host,count(eventid) totalevents from events,       (select t1.macid,t1.id_host  from dblink('port=5432 dbname=PIAMDB',     'select lower(macid),id_host from piamapp."controllerMaster"') as t1(macid character varying,id_host integer)) a        where lower(events.macid)=a.macid       and serverdatetime>=now()-interval '1 hour'     group by a.id_host)     select sum(case when id_host=1 then totalevents else 0 end) as count_10_137_2_124,      sum(case when id_host=2 then totalevents else 0 end) as count_10_137_2_123,     sum(case when id_host=3 then totalevents else 0 end) as count_10_137_2_96,      sum(case when id_host=4 then totalevents else 0 end) as count_10_137_2_97,sum(case when id_host=7 then totalevents else 0 end) as count_10_204_185_140,   sum(case when id_host=9 then totalevents else 0 end) as count_10_137_144_138,  sum(case when id_host=10 then totalevents else 0 end) as count_10_137_144_141,   sum(case when id_host=11 then totalevents else 0 end) as count_10_137_12_35,    sum(case when id_host=12 then totalevents else 0 end) as count_10_204_195_142__10_148_64_12,    sum(case when id_host=13 then totalevents else 0 end) as count_10_137_144_105, sum(case when id_host=14 then totalevents else 0 end) as count_10_137_144_140,   sum(case when id_host=15 then totalevents else 0 end) as count_10_137_144_142,  sum(case when id_host=16 then totalevents else 0 end) as count_10_137_144_139,  sum(case when id_host=17 then totalevents else 0 end) as count_10_137_144_108,  sum(case when id_host=19 then totalevents else 0 end) as count_10_137_144_60,   sum(case when id_host=20 then totalevents else 0 end) as count_10_137_144_61,   sum(case when id_host=21 then totalevents else 0 end) as count_10_137_144_62,   sum(case when id_host=22 then totalevents else 0 end) as count_10_137_144_122,  sum(case when id_host=23 then totalevents else 0 end) as count_10_137_144_54,   sum(case when id_host=25 then totalevents else 0 end) as count_10_137_144_109,  sum(case when id_host=29 then totalevents else 0 end) as count_10_137_144_46,   sum(case when id_host=30 then totalevents else 0 end) as count_10_137_144_55,   sum(case when id_host=31 then totalevents else 0 end) as count_10_137_144_56,   sum(case when id_host=34 then totalevents else 0 end) as count_10_137_144_121,  sum(case when id_host=35 then totalevents else 0 end) as count_10_137_144_119,  sum(case when id_host=36 then totalevents else 0 end) as count_10_137_144_115,  sum(case when id_host=37 then totalevents else 0 end) as count_10_128_23_157,   sum(case when id_host=38 then totalevents else 0 end) as count_10_137_144_120,  sum(case when id_host=39 then totalevents else 0 end) as count_10_137_144_116,  sum(case when id_host=40 then totalevents else 0 end) as count_10_135_140_215,  sum(case when id_host=41 then totalevents else 0 end) as count_10_137_144_104, sum(case when id_host=42 then totalevents else 0 end) as count_10_137_144_92,    sum(case when id_host=43 then totalevents else 0 end) as count_10_137_144_91,   sum(case when id_host=44 then totalevents else 0 end) as count_10_137_144_79,   sum(case when id_host=45 then totalevents else 0 end) as count_10_137_144_80,   sum(case when id_host=46 then totalevents else 0 end) as count_10_137_144_78,   sum(case when id_host=47 then totalevents else 0 end) as count_10_137_2_67,     sum(case when id_host=48 then totalevents else 0 end) as count_10_137_144_96,   sum(case when id_host=49 then totalevents else 0 end) as count_10_137_144_97,   sum(case when id_host=50 then totalevents else 0 end) as count_10_137_144_98,   sum(case when id_host=52 then totalevents else 0 end) as count_10_137_144_147,  sum(case when id_host=53 then totalevents else 0 end) as count_10_137_144_148,  sum(case when id_host=54 then totalevents else 0 end) as count_10_137_144_149,  sum(case when id_host=55 then totalevents else 0 end) as count_10_137_144_152,  sum(case when id_host=56 then totalevents else 0 end) as count_10_137_144_153,  sum(case when id_host=57 then totalevents else 0 end) as count_10_137_144_87,   sum(case when id_host=58 then totalevents else 0 end) as count_10_137_144_88,   sum(case when id_host=59 then totalevents else 0 end) as count_10_137_144_89,   sum(case when id_host=60 then totalevents else 0 end) as count_10_137_144_90,   sum(case when id_host=61 then totalevents else 0 end) as count_10_137_144_118,  sum(case when id_host=62 then totalevents else 0 end) as count_10_137_144_154,  sum(case when id_host=63 then totalevents else 0 end) as count_10_137_144_163, sum(case when id_host=64 then totalevents else 0 end) as count_10_137_144_164,   sum(case when id_host=65 then totalevents else 0 end) as count_10_137_144_165,  sum(case when id_host=66 then totalevents else 0 end) as count_10_137_144_166,  sum(case when id_host=67 then totalevents else 0 end) as count_10_137_144_167,  sum(case when id_host=68 then totalevents else 0 end) as count_10_137_144_168,  sum(case when id_host=69 then totalevents else 0 end) as count_10_137_144_169,  sum(case when id_host=70 then totalevents else 0 end) as count_10_137_144_161,  sum(case when id_host=71 then totalevents else 0 end) as count_10_137_144_162   from t1) TO '/home/jioapp/mailoutput/acs_core_server_onehour_count/ACS_HOURLY_COUNT.csv' WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/acs_core_server_onehour_count/ACS_HOURLY_COUNT.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find the Today Query count on $NOW.

For more details go through the attachment.

Regards,
JIONOC IT
EOF

$MAILX -s "ACS Core Server Count For Last One Hour" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

