###############################################################################################
# Name       : alarm_parked.sh						      		      #
# Description: Alarms Under Parked State					 	      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################


#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"alarm_parked.$NOW.csv"
MailToList="Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Girish.Juneja@ril.com,Shalini.Jaiswal@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,rjilsecurity.operationscentre@ril.com,JioNOC.ITDRSupport@ril.com,Jio.TopsSLPAppSupport@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (Select * from (select alarmid, macid,sap_id,alarmdiscription,idresoltype,alarmstatus,RANK() OVER (partition by alarmid ORDER BY alarmstatus desc) alarmid_rank,count(*) from (select * from public.livealarmshistory where serverdatetime > NOW() - Interval '14 days' and alarmstatus In(2,4,5) ) A group by  alarmid, macid,sap_id,alarmdiscription,alarmstatus, idresoltype order by alarmid) as AA where alarmid_rank ='1' and alarmstatus !='5') TO '/home/jioapp/mailoutput/generic/alarmparked.csv' WITH CSV HEADER
EOF`

cat > $Mailbody << EOF
Dear All,

Please find Alarms Under Parked State on $NOW


Regards,
JIONOC IT
EOF

cat /home/jioapp/mailoutput/generic/alarmparked.csv > $OUPUTFILECSV

$MAILX -s "Alarms Under Parked State $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

