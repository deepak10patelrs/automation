################################################################################################
# Name       : ZERO_Attendance_Count_For_Last_One_Hour.sh		       		       #
# Description: It check last one hour count in attendance_details table which must be non-zero #
# Auto Mail  : Yes					       			               #
# Author     : Deepak Patel						                       #
################################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/attendance_scheduler_for_zero_count/MAILBODY
#OUPUTFILECSV=/home/jioapp/mailoutput/attendance_scheduler_for_zero_count/"Output.$NOW.csv"
MailToList="JioNOC.ITDRSupport@ril.com,Jio.TopsSLPAppSupport@ril.com,Jio.TopsNOSQL@ril.com"
#cc_list="Jio.TopsNOSQL@ril.com"

MAILX='mailx'

VAL=`/usr/local/pgsql/bin/psql $dbname $username << EOF

--select count (*) from attendence_details where serverdatetime >=now()-interval '60 mins'

select count(*) FROM public.attendence_details where eventdate between now()-interval '35 mins' and now()-interval '30 mins'

EOF`

echo $VAL > /home/jioapp/mailoutput/attendance_scheduler_for_zero_count/count.txt

cat > $Mailbody << EOF
Dear All,

Sync is still running, this mail is just for DBA analysis purpose.

ZERO RECORDS UPDATED IN ATTENDANCE TABLE. PLEASE CHECK ATTENDANCE SCHEDULER AND LOGS.


$VAL.


Regards,
JIONOC IT
EOF


count1=`cat /home/jioapp/mailoutput/attendance_scheduler_for_zero_count/count.txt|awk '{print $3}'`

if [ $count1 -le 0 ]
then
`$MAILX -s "Data Sync is runnnig - Just for DBA analysis purpose $NOW" -r "jionoc.it@ril.com" $MailToList < $Mailbody`
#else
#exit 0
fi

echo $count1 > /home/jioapp/ssm/zero_count.txt 
