###########################################################
# Name       : Euronet_sync.sh                            #
# Description: PIAM Euronet Sync up Error Report          #
# Auto Mail  : Yes                                        #
# Author     : Deepak Patel                               #
###########################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/euronet/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/euronet/"euronet_syncup_errlog.$NOW.csv"
MailToList="Jaideep.Mokha@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Sankara.Suravaram@ril.com,deepak10.patel@ril.com,sanket.kulkarni@ril.com,jadvinder.singh@ril.com,abhijit1.gaikwad@ril.com,makarand.upadhye@ril.com,Manish.S.Deshmukh@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"

MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF

\copy (SELECT  employeeid, cardnumber,  remark, cast (logdate as date), issuelevel,  facilitycode, oldfacilitycode FROM public.euronetlogs where logdate> NOW()- Interval '12 hrs' and remark not like '%Success%') TO '/home/jioapp/mailoutput/euronet/euronet_syncup_errlog.csv' WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/euronet/euronet_syncup_errlog.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find PIAM Euronet Sync up Error $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "PIAM Euronet Sync up Error $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody
