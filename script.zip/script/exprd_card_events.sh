###########################################################################################
# Name       : exprd_card_events.sh		                 		  	  #
# Description: To find cards which are sending events even after expiry      		  #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/euronet/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/euronet/"expired_card.$NOW.csv"
MailToList="Jaideep.Mokha@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Sankara.Suravaram@ril.com,deepak10.patel@ril.com,sanket.kulkarni@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (Select * from ( SELECT tb2.cardnumber, tb2.employeeid, tb2.facilitycode,tb2.expiry_date, tb2.employeestatus FROM   dblink('dbname=PIAMDB','(select distinct cardnumber, employeeid,facilitycode,cast(todate as date), status  from piamapp.mapping_cardholder_card WHERE  status=''1'' and (todate < now() - interval ''1'' day)  order by todate desc ) ') AS tb2( cardnumber bigint, employeeid varchar(20), facilitycode varchar(20),expiry_date date , employeestatus varchar(20) )) A  join ( select  distinct cardnumber,employeeid,macid,eventname,facilitycode,max(cast (serverdatetime as date )),min(cast (serverdatetime as date )) from events where serverdatetime > NOW() - Interval '4 hr' and  eventname In('EXIT GRANTED','ENTRY GRANTED') group by cardnumber,employeeid,facilitycode,macid,eventname)B on b.employeeid=cast (a.employeeid as varchar(20))  order by a.expiry_date desc) TO '/home/jioapp/mailoutput/euronet/expired_card.csv' WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/euronet/expired_card.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find Expired card with events $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Expired card with events $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody


