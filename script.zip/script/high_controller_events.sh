###############################################################################################
# Name       : high_controller_events.sh		       		      		      #
# Description: To find controllers generating high event for DFO,DHO			      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################


dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/high_controller_events/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/high_controller_events/"Output_CoreCount.$NOW.csv"
MailToList="JioNOC.ITDRSupport@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Ritesh.Parekh@ril.com,Sanket.Kulkarni@ril.com,Rahul1.Dalvi@ril.com,Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Awadhesh1.Yadav@ril.com,Thisore.Raghu@ril.com,Jignesh.Purohit@ril.com,Saurabh.Bhatnagar@ril.com,Omprakash.Tiwari@ril.com,deepak10.patel@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
#MailToList="deepak10.patel@ril.com"

MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF

\copy (Select *,CASE When state_name In('Assam','Bihar','Jharkhand','Kolkata','NorthEast','Orissa','West Bengal') Then 'East' When state_name In ('Chhattisgarh','Goa','Gujarat','Madhya Pradesh','Maharashtra','Mumbai','Rajasthan') Then 'West' When state_name IN('Delhi','Haryana','Himachal Pradesh','Jammu','Kashmir','Punjab','Uttar Pradesh (East)','Uttar Pradesh (West)','Uttar Pradesh (West)','Uttaranchal') Then 'North'  When state_name IN('Andhra Pradesh','Karnataka','Kerala','Tamil Nadu','Telangana') Then 'South' Else 'Unknown' End as Region from (select * from (select macid ,alarmdiscription,sap_id,substring(sap_id,6,4),count(*)  from (select  * from events where serverdatetime  > now()-interval '1 day') A group by macid,alarmdiscription,sap_id having  count(*)  > 1000 order by count(*) desc) as AA left  join (SELECT  cityname, citycode, statecode, state_name, cmp  FROM public.city) as B on AA.substring = B.citycode ) as CC) TO '/home/jioapp/mailoutput/high_controller_events/Output_CoreCount.csv' WITH CSV HEADER

EOF`

cat /home/jioapp/mailoutput/high_controller_events/Output_CoreCount.csv > $OUPUTFILECSV

cat > $Mailbody << EOF
Dear All,

Please find the high events from controllers on $NOW



Regards,
JIONOC IT 
EOF

$MAILX -s "Controllers with high events $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV  $MailToList < $Mailbody

