###############################################################################################
# Name       : slp_servers_to_configure_on_controllers.sh		      		      #
# Description: mapping of controller on available servers i.e load distribution 	      #
# Auto Mail  : Yes					       			              #
# Author     : Deepak Patel						                      #
###############################################################################################


#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/slp_servers_to_configure_on_controllers/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/slp_servers_to_configure_on_controllers.sh/"Output_CoreCount.$NOW.csv"
MailToList="JioNOC.ITDRSupport@ril.com,Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Ritesh.Parekh@ril.com,rahul1.dalvi@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com,Amiya2.Panda@ril.com,Sanjeev4.Singh@ril.com,Vinay.Dubey@ril.com,Aparnesh.Mitra@ril.com,Dharmendra1.Shukla@ril.com,Ambuj1.Sharma@ril.com,Jignesh.Purohit@ril.com,Saurabh.Bhatnagar@ril.com,Raj18.Singh@ril.com"

MAILX='mailx'

VAL=`/usr/local/pgsql/bin/psql $dbname $username << EOF
select idhostbycount.id_host,configure_server as cntrlhscd, hostip1 , row_number() over (order by idhostbycount.id_host ) as priority from (select id_host,count(*) as "configure_server" from piamapp."controllerMaster" group by id_host having count(*) <6001)  as idhostbycount  ,  (select id_host,hostip1 from piamapp."hostMaster" where trim(hostip1) in  ('2405:200:a10:fc8b:10:137:144:163','2405:200:a10:fc8b:10:137:144:164','2405:200:a10:fc8b:10:137:144:167','2405:200:a10:fc8b:10:137:144:168','2405:200:a10:fc8b:10:137:144:169')) as idhostip where idhostbycount.id_host=idhostip.id_host limit 3
EOF`

cat > $Mailbody << EOF
Dear All,

Please find the Host to be configured data on $NOW


$VAL.


Regards,
JIONOC IT
EOF

$MAILX -s "SLP servers to configure on controllers $NOW" -r "jionoc.it@ril.com"  $MailToList < $Mailbody

