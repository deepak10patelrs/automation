###########################################################################
# Name       : pingstatus.sh                              		  #
# Description: To check ping status of PIAM controllers which are offline #
# Auto Mail  : Yes                                        		  #
# Author     : Deepak Patel                               		  #
###########################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY12
OUPUTFILECSV=/home/jioapp/mailoutput/"ping_status.$NOW.csv"
#MailToList="deepak10.patel@ril.com"
MailToList="Rahul1.Dalvi@ril.com,Jaideep.Mokha@ril.com,rashmi1.rai@ril.com,Jio.TopsSLPAppSupport@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (SELECT controllerip,macid,description,sap_id FROM piamapp."controllerMaster") To '/home/jioapp/mailoutput/generic/final_output.csv' WITH CSV
EOF`

cat > $Mailbody << EOF
Dear All,

Please find reachability status of PIAM Controllers  $NOW


Regards,
JIONOC IT
EOF

cp /home/jiobi/pingstatus.csv /home/jioapp/mailoutput/generic/

cat /home/jioapp/mailoutput/generic/pingstatus.csv|awk -F "," '{print $1,$3}' > /home/jioapp/mailoutput/generic/pingstatus_final.csv

sed -i 's/ /,/g' /home/jioapp/mailoutput/generic/pingstatus_final.csv

sort -k1 /home/jioapp/mailoutput/generic/pingstatus_final.csv > /home/jioapp/mailoutput/generic/sorted_pingstatus_final.csv

sort -k1 /home/jioapp/mailoutput/generic/final_output.csv > /home/jioapp/mailoutput/generic/sorted_final_output.csv

join -t, -2 1 -1 1 -a 1 /home/jioapp/mailoutput/generic/sorted_final_output.csv /home/jioapp/mailoutput/generic/sorted_pingstatus_final.csv>  /home/jioapp/mailoutput/generic/pingstat.csv

sed -i '1iControllerIP,macid,description,sap_id,Status' /home/jioapp/mailoutput/generic/pingstat.csv


cat /home/jioapp/mailoutput/generic/pingstat.csv > $OUPUTFILECSV

gzip $OUPUTFILECSV

finalping=/home/jioapp/mailoutput/"ping_status.$NOW.csv.gz"

$MAILX -s "PIAM Controllers Reachability Status $NOW" -r "jionoc.it@ril.com" -a $finalping $MailToList < $Mailbody

