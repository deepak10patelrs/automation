###########################################################################################
# Name       : controller_integration_status_last15.sh                  		  #
# Description: To find controllers added in last 15 days and events received against them #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"output_integration_status.$NOW.csv"
MailToList="Shakti.Sharma@ril.com,Vikas.Madhok@ril.com,Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Saurabh.Bhatnagar@ril.com,Jignesh.Purohit@ril.com,Dileep.Deshmukh@ril.com,Pranav.M.Vyas@ril.com,Sonali.Dubale@ril.com,Shalini.Jaiswal@ril.com,Govind.M.Mishra@ril.com,Raj18.Singh@ril.com,Jio.TopsSLPAppSupport@ril.com,rjilsecurity.operationscentre@ril.com,Manish.Sondhi@ril.com,Sanket.Kulkarni@ril.com,Girish.Juneja@ril.com,Sujit1.Mohite@zmail.ril.com"
#MailToList="deepak10.patel@ril.com"
MAILX='mailx'

`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (Select *,CASE When state_name In('Assam','Bihar','Jharkhand','Kolkata','NorthEast','Orissa','West Bengal') Then 'East' When state_name In ('Chhattisgarh','Goa','Gujarat','Madhya Pradesh','Maharashtra','Mumbai','Rajasthan') Then 'West' When state_name IN('Delhi','Haryana','Himachal Pradesh','Jammu','Kashmir','Punjab','Uttar Pradesh (East)','Uttar Pradesh (West)','Uttaranchal') Then 'North' When state_name IN('Andhra Pradesh','Karnataka','Kerala','Tamil Nadu','Telangana') Then 'South' Else 'Unknown' End as Region  from (select * FROM dblink('dbname=PIAMDB','(select description,controllerip,macid, sap_id,substring(sap_id,6,4), firmwareversion,id_oem, controlleriptype,createdon,createdby,isonline from piamapp."controllerMaster" where createdon>NOW()- Interval ''1 day'')')As tb1(description varchar(40),controllerip varchar(40),macid varchar(40),sap_id_orig varchar(40),sap_id varchar(40),firmwareversion varchar(40),id_oem integer,controlleriptype integer,createdon timestamp without time zone,createdby varchar(100),isonline varchar(20)))as  AA left join (Select macid,eventname,max(controllerdate)as Eventmax,min(controllerdate) as Eventmin  from Public.events where serverdatetime > NOW()- Interval '1 days' and idalarm in(1,2,3,4,172,130) group by macid,eventname) as B on AA.macid = B.macid left join (Select macid,alarmname,max(controllerdatetime) as Alarmmax,min(controllerdatetime )as Alarmin  from Public.livealarmshistory where serverdatetime > NOW()- Interval '1 days' and idalarm IN(24,38,39) group by macid,alarmname) as C on AA.macid = C.macid left join (SELECT  cityname, citycode, statecode, state_name, cmp  FROM public.city) as D on AA.sap_id = D.citycode) TO '/home/jioapp/mailoutput/generic/output_integration.csv'  WITH CSV HEADER
EOF`

cat /home/jioapp/mailoutput/generic/output_integration.csv> $OUPUTFILECSV

count=`cat /home/jioapp/mailoutput/generic/output_integration.csv|awk -F "," '{print $1}'|sed '/^$/d'|grep -oP '\b[A-Z0-9_]+\b'|wc -l`

#count=`cat /home/jioapp/mailoutput/generic/output_integration.csv|grep ^IN|wc -l`

cat > $Mailbody << EOF
Dear All,

The count of testing status of New Integration added is $count till  $NOW


Regards,
JIONOC IT
EOF

$MAILX -s "Testing status of New Integration $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody
