#!/bin/bash
dbname="PIAM_TRANS_DB"
username="postgres"
NOW=$(date +"%d-%m-%Y-%H%M%S")
Mailbody=/home/jioapp/mailoutput/macid_entryexit_noevents/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/macid_entryexit_noevents/"output.$NOW.txt"
MailToList="dileep.deshmukh@ril.com,pranav.m.vyas@ril.com,sanket.kulkarni@ril.com,makarand.upadhye@ril.com,JioNOC.ITDRSupport@ril.com,RCPsecurity.Operationscentre@ril.com,Jio.TopsSLPAppSupport@ril.com,Shalini.Jaiswal@ril.com,Girish.Juneja@ril.com"
MAILX='mailx'
cat > $Mailbody << EOF
Dear All,

Please find the attachment for list of MACID’s with NO entry granted and exit granted events for TC22 controllers on $NOW.

Regards,
JIONOC IT
EOF

VAL=`/usr/local/pgsql/bin/psql $dbname $username << EOF
SELECT distinct macid FROM
dblink('port=5432 dbname=PIAMDB'::text, 'SELECT LOWER(macid) macid,controllerip FROM piamapp."controllerMaster"'::text) ressetoem(macid character varying,controllerip character varying)
WHERE lower(macid) not in(SELECT lower(macid) macid FROM events where serverdatetime>=now()-interval '1 hours'
AND idalarm in (1,2)) AND ressetoem.controllerip in('10.50.197.55','10.50.197.56','10.50.197.57','10.50.197.58','10.50.197.59','10.50.197.59','10.50.197.61','10.50.197.62','10.50.197.63','10.50.197.64','10.50.62.31','10.50.62.33','10.50.62.34','10.50.62.38','10.51.16.10','10.51.16.11','10.51.16.12','10.51.16.13','10.51.16.26');
EOF`
echo $VAL > $OUPUTFILECSV
$MAILX -s "MACID list for NO events of ENTRY and EXIT for last 2 hours on $NOW" -r "jionoc.it@ril.com" -a $OUPUTFILECSV $MailToList < $Mailbody

