###########################################################################################
# Name       : online_offline.sh		                 		  	  #
# Description: To find controllers offline/online status trendwise report by macid	  #
# Auto Mail  : Yes                                        				  #
# Author     : Deepak Patel                               				  #
###########################################################################################

#!/bin/bash
dbname="PIAMDB"
username="postgres"
NOW=$(date +"%d-%m-%Y")
day=`date +%d`
date_var=`date +%Y%m%d`
Mailbody=/home/jioapp/mailoutput/generic/MAILBODY
OUPUTFILECSV=/home/jioapp/mailoutput/generic/"output_status_test.$day.csv"
MailToList="Jio.TopsSLPAppSupport@ril.com,Jaideep.Mokha@ril.com,Rashmi1.Rai@ril.com,Rahul1.Dalvi@ril.com,Jignesh.Purohit@ril.com,Dileep.Deshmukh@ril.com,Girish.Juneja@ril.com,Raj18.Singh@ril.com"
#MailToList="deepak10.patel@ril.com"

MAILX='mailx'

cat > $Mailbody << EOF
Dear All,

Please find Controllers online and offline Status trend report by macid $NOW


Regards,
JIONOC IT
EOF


`/usr/local/pgsql/bin/psql $dbname $username << EOF
\copy (select macid,isonline from piamapp."controllerMaster") TO '/home/jioapp/mailoutput/generic/Output_offline_testping.csv' WITH CSV HEADER
EOF`

temp_head2=`head -2 /home/jioapp/mailoutput/generic/last_days_data_test1.csv|tail -1|cut -d, -f2-`
temp_head1=`head -1 /home/jioapp/mailoutput/generic/last_days_data_test1.csv|cut -d, -f2-`


`sed 1,2d /home/jioapp/mailoutput/generic/last_days_data_test1.csv > /home/jioapp/mailoutput/generic/last_days_data1_test.csv`
`sed 1d /home/jioapp/mailoutput/generic/Output_offline_testping.csv > /home/jioapp/mailoutput/generic/output1_test.csv`

sort -t, -k1,1 /home/jioapp/mailoutput/generic/last_days_data1_test.csv > /home/jioapp/mailoutput/generic/last_days_data1_test_sorted.csv
sort -t, -k1,1 /home/jioapp/mailoutput/generic/output1_test.csv > /home/jioapp/mailoutput/generic/output1_sorted_test.csv


join -t, -1 1 -2 1 -a 2 -o 2.1,2.2,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,1.10,1.11,1.12,1.13,1.14,1.15,1.16,1.17,1.18,1.19,1.20,1.21,1.22,1.23,1.24,1.25,1.26,1.27,1.28,1.29,1.30 /home/jioapp/mailoutput/generic/last_days_data1_test_sorted.csv /home/jioapp/mailoutput/generic/output1_sorted_test.csv > /home/jioapp/mailoutput/generic/joinfinal.csv

cat /home/jioapp/mailoutput/generic/pingstat.csv|awk -F"," '{print $2,$3}'|sed 's/ /,/g' >$HOME/test/abc.csv

sed  1d /home/jioapp/test/abc.csv > /home/jioapp/test/abc1.csv

sort -t, -k1,1 /home/jioapp/test/abc1.csv > /home/jioapp/test/sorted_abc.csv

sort -t, -k1,1 /home/jioapp/mailoutput/generic/joinfinal.csv > /home/jioapp/test/sorted_data.csv

#join -t, -2 1 -1 1  /home/jioapp/test/sorted_abc.csv /home/jioapp/test/sorted_data.csv -a 1 > /home/jioapp/test/finaljoin.csv

join -t, -1 1 -2 1 -a 1 /home/jioapp/test/sorted_abc.csv /home/jioapp/test/sorted_data.csv > /home/jioapp/test/finaljoin.csv

cat /home/jioapp/test/finaljoin.csv |sort -nk1|uniq -c|awk -F" " '{ for (i=2; i<=NF; i++) print $i}' > /home/jioapp/test/mailfile.csv

sed -i '1iMacid,Ping_Status,PIAM_Status,'$temp_head2'' /home/jioapp/test/mailfile.csv

sed -i '1iSr,Date,'$date_var','$temp_head1'' /home/jioapp/test/mailfile.csv

cat /home/jioapp/test/mailfile.csv > /home/jioapp/mailoutput/generic/last_days_data_test1.csv

cat /home/jioapp/test/mailfile.csv > $OUPUTFILECSV

gzip $OUPUTFILECSV

fin=/home/jioapp/mailoutput/generic/"output_status_test.$day.csv.gz"

$MAILX -s "Field Visit-Historic controller information for $NOW" -r "jionoc.it@ril.com" -a $fin $MailToList < $Mailbody
